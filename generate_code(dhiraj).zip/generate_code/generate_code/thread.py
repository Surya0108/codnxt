import threading
import random
import datetime
import mysql.connector
from mysql.connector import Error
from django.utils import timezone
import pymysql
class DataUploadThread(threading.Thread):

    def __init__(self,branch_id , variant_id , number_of_codes, cd_id ):
        self.cd_id = int(cd_id)
        self.branch_id = int(branch_id)
        self.variant_id = int(variant_id)
        self.number_of_codes = int(number_of_codes)
        threading.Thread.__init__(self)
    
    def run(self):
        i=0
        while i<self.number_of_codes:
            temp_code=''
            code=str(self.branch_id)+str(self.variant_id)
            temp_code+=code
            remaining_length=10-len(temp_code)
            numerical_code=temp_code+str(random.randint(10**(remaining_length-1), (10**remaining_length)-1))
            numerical_code=int(numerical_code)
            today=timezone.now()
            try:
                connection = mysql.connector.connect(host='10.0.2.115',database='codnxt_db',user='tb_user',password="dJq%E5p$")
                if connection.is_connected():
                    cursor = connection.cursor()
                    if self.branch_id == 1:
                        mySql_insert_query = "INSERT INTO code_four_square(cd_id,branch,variant,code,status,create_date) values(%s, %s, %s, %s, %s, %s)"
                    elif self.branch_id == 2:
                        mySql_insert_query = "INSERT INTO code_red_and_white(cd_id,branch,variant,code,status,create_date) values( %s, %s, %s, %s, %s, %s)" 
                    elif self.branch_id == 3:
                        mySql_insert_query = "INSERT INTO code_cavenders_green(cd_id,branch,variant,code,status,create_date) values( %s, %s, %s, %s, %s, %s)" 
                    elif self.branch_id == 4:
                        mySql_insert_query = "INSERT INTO code_cavenders_gold(cd_id,branch,variant,code,status,create_date) values(%s, %s, %s, %s, %s, %s)" 
                    elif self.branch_id == 5:
                        mySql_insert_query = "INSERT INTO code_cavenders_special(cd_id,branch,variant,code,status,create_date) values(%s, %s, %s, %s, %s, %s)"
                    elif self.branch_id == 6:
                        mySql_insert_query = "INSERT INTO code_stellar(cd_id,branch,variant,code,status,create_date) values(%s, %s, %s, %s, %s, %s)"
                    elif self.branch_id == 7:
                        mySql_insert_query = "INSERT INTO code_north_pole(cd_id,branch,variant,code,status,create_date) values(%s, %s, %s, %s, %s, %s)"
                    elif self.branch_id == 8:
                        mySql_insert_query = "INSERT INTO code_tipper(cd_id,branch,variant,code,status,create_date) values(%s, %s, %s, %s, %s, %s)"
                    elif self.branch_id == 12:
                        mySql_insert_query = "INSERT INTO code_flavour_and_lights(cd_id,branch,variant,code,status,create_date) values(%s, %s, %s, %s, %s, %s)"
                    val=(self.cd_id,self.branch_id,self.variant_id,numerical_code,1,today)
                    cursor.execute(mySql_insert_query,val)  
                    connection.commit()  
                    i+=1
                    cursor.close()
            except Exception as e:
                pass
            finally:
                if connection.is_connected():
                    connection.close()