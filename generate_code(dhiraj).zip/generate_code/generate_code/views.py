from rest_framework import status,generics
from rest_framework.response import Response
from .thread import DataUploadThread

class GenerateCode(generics.GenericAPIView):
    def post(self,request,*args,**kwargs):
        try:
            branch_id=request.data['branch_id']
            variant_id=request.data['variant_id']
            number_of_codes=request.data['number_of_codes']
            cd_id=request.data['cd_id']
            if not branch_id or not variant_id or not number_of_codes or not cd_id:
                context = {"status":False,"message":"Enter all Parameters"}
            else:
                DataUploadThread(branch_id,variant_id,number_of_codes,cd_id).start()
                context = {"status":True,"message":"Codes Generated Successfully"}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'error':str(e)}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
