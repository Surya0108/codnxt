
from django.urls import path
from .views import *

urlpatterns = [
    path('api/generate_code/',GenerateCode.as_view(),name='generate_code'),
]
